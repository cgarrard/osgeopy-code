ospybook
========

This module was written as a companion to `Geoprocessing with Python <http://manning.com/garrard/?a_aid=geopy&a_bid=c3bae5be>`_.
